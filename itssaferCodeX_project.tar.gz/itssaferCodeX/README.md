# itssafer CodeX

Android aplikácia na obojsmernú konverziu textu medzi slovenskou/latinskou abecedou, číslami a špecifickými arabskými znakmi. Vytvorené v jazyku Kotlin, minSdk 33, package: org.itssafer.codex.

## Funkcie
- Real-time konverzia medzi SK/latinkou a arabskými znakmi
- Zachovanie medzier
- Kopírovanie výsledku do schránky

## Autor
Kristián Kašnik - itssafer.org
