<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

Toto je Android projekt v jazyku Kotlin. Komentáre v kóde píš v slovenčine, samotný kód a názvy premenných/funkcií v angličtine podľa štandardných konvencií.
