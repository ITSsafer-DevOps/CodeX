package org.itssafer.codex

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    // Jednoduchá substitučná šifra: ROT13 pre písmená, ROT5 pre čísla
    private fun encryptSimpleShift(input: String): String {
        val sb = StringBuilder()
        for (c in input) {
            when {
                c in 'A'..'Z' -> sb.append('A' + (c - 'A' + 13) % 26)
                c in 'a'..'z' -> sb.append('a' + (c - 'a' + 13) % 26)
                c in '0'..'9' -> sb.append('0' + (c - '0' + 5) % 10)
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun decryptSimpleShift(input: String): String {
        val sb = StringBuilder()
        for (c in input) {
            when {
                c in 'A'..'Z' -> sb.append('A' + (c - 'A' + 13) % 26)
                c in 'a'..'z' -> sb.append('a' + (c - 'a' + 13) % 26)
                c in '0'..'9' -> sb.append('0' + (c - '0' + 5) % 10)
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializácia UI prvkov
        val editTextInput = findViewById<EditText>(R.id.editText_input)
        val editTextOutput = findViewById<EditText>(R.id.editText_output)
        val buttonCopy = findViewById<Button>(R.id.button_copy)
        val textViewBranding = findViewById<TextView>(R.id.textView_branding)

        // Nastavenie výstupného EditTextu ako needitovateľného
        editTextOutput.isFocusable = false
        editTextOutput.isClickable = false
        editTextOutput.isCursorVisible = false
        editTextOutput.isLongClickable = false

        // TextWatcher pre real-time konverziu
        var lastOutput = ""
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val input = s?.toString() ?: ""
                val output = if (isLikelyCipher(input)) {
                    decryptSimpleShift(input)
                } else {
                    encryptSimpleShift(input)
                }
                if (output != lastOutput) {
                    lastOutput = output
                    editTextOutput.setText(output)
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        }
        editTextInput.addTextChangedListener(textWatcher)

        // Kopírovanie do schránky
        buttonCopy.setOnClickListener {
            val textToCopy = editTextOutput.text.toString()
            if (textToCopy.isNotEmpty()) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("converted_text", textToCopy)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "Text skopírovaný!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Niet čo kopírovať!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Funkcia na detekciu šifrovaného textu (heuristika: ak obsahuje aspoň 2 znaky z posunutej abecedy)
    private fun isLikelyCipher(text: CharSequence): Boolean {
        val rot13Chars = (('A'..'Z') + ('a'..'z')).map { encryptSimpleShift(it.toString())[0] }.toSet()
        val rot5Chars = ('0'..'9').map { encryptSimpleShift(it.toString())[0] }.toSet()
        return text.count { it in rot13Chars || it in rot5Chars } > 1
    }
}
